const axios = require("axios");

const fetchGitHubRepos = async (username) => {
  const res = await axios.get(`https://api.github.com/users/${username}/repos`, {
    headers: {
      Authorization: `token ${process.env.GITHUB_TOKEN}`,
    },
  });
  return res.data;
};

module.exports = { fetchGitHubRepos };
